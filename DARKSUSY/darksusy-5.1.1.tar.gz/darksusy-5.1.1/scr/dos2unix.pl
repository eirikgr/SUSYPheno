#!/usr/bin/perl -pi
s/\r\n/\n/;
