*         -*- mode: fortran -*-
*######################################################################*
*                       i n c l u d e     f i l e                      *
*######################################################################*

************************************************************************
***                           dsntdkcom.h                              ***
***         this piece of code is needed as a separate file          ***
c----------------------------------------------------------------------c
c  author: joakim edsjo (edsjo@physto.se), april 6, 1999
c  modified: april 6, 1999

      real*8 dklambda
      common /dkvar/dklambda

      save /dkvar/

************************** end of dsntdkcom.h ****************************






