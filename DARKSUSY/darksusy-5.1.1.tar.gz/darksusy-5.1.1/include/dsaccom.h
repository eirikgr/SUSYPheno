*         -*- mode: fortran -*-
      character*8 aclabel
      real*8 gzinv,bsg,gm2muon
      common /dsaccom/gzinv,bsg,gm2muon,aclabel
      save /dsaccom/
