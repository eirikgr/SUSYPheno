*         -*- mode: fortran -*-
      real*8 ftp(7:12),ftn(7:12),delu,deld,dels
      integer ddpole,dddn
      character*10 ddffsi,ddffsd
      common /ddcom/ftp,ftn,delu,deld,dels,ddpole,dddn,ddffsi,ddffsd
      save /ddcom/

