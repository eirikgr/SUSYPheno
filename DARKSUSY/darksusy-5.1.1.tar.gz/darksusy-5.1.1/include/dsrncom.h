*         -*- mode: fortran -*-
*######################################################################*
*                       i n c l u d e     f i l e                      *
*######################################################################*

************************************************************************
***                             dsrncom.h                            ***
***         this piece of code is needed as a separate file          ***
***             the rest of the code 'includes' dsrncom.h            ***
c----------------------------------------------------------------------c
c  author: paolo gondolo 2000
c  modified: Joakim Edsjo 2001-09-11
      integer omtype,omfast
      common /rnpar/ omtype,omfast
***                                                                 ***
************************ end of dsrncom.h *****************************
