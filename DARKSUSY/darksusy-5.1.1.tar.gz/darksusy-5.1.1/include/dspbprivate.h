*         -*- mode: fortran -*-
c      include 'pbpar.h'
      real*8 zerovec(300),zero,dh,dg,axsec,lambdag,gamh,lambdah
      common /dspbprivate/zero,dh,dg,axsec,lambdag,gamh,lambdah,zerovec
      save /dspbprivate/
