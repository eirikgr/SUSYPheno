// GALPROP C++ v41 public release: Dummy routine

//**.****|****.****|****.****|****.****|****.****|****.****|****.****|****.****|
// * Kcapture_cs.cc *                              galprop package * 2001/08/16
//**"****!****"****!****"****!****"****!****"****!****"****!****"****!****"****|

//**.****|****.****|****.****|****.****|****.****|****.****|****.****|****.****|

void Kcapture_cs(double Ek, int Zp, int Zt, double *attach, double *strip)
{
   *attach = *strip = 0.;
   return;
}

