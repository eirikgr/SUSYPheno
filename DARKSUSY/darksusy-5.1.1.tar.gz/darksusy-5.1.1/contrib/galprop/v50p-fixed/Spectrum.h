
//**.****|****.****|****.****|****.****|****.****|****.****|****.****|****.****|
// * Spectrum.h *                                  galprop package * 4/14/2000 
//**"****!****"****!****"****!****"****!****"****!****"****!****"****!****"****|

#ifndef Spectrum_h
#define Spectrum_h

class Spectrum
{
 public: 

  double  *s; //AWS20050624
};

#endif
