// next fixes are for g++ 4.5 -- PG 20091126
#include <cstring>
#include <cstdlib>
