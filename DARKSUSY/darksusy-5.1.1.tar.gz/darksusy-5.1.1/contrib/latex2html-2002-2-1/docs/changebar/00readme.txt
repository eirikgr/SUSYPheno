                               changebar bundle

                                 June 30, 1995

This bundle contains a package that I maintain to add changebars to a
LaTeX document.

It provides the changebar environment as well as the commands cbstart
and cbend. It uses \specials to communicate to the dvi driver where
the bars should be printed.

The file chbar.sh which is part of this bundle was contributed. It can
be used to compare two versions of a document and automatically add
the changebars.
